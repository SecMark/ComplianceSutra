import React from 'react'
import "./style.css"
function BoardView({ }) {

    return (
        <div>
            <p>Dashboard View</p>
        </div>
    )

}

export default BoardView;