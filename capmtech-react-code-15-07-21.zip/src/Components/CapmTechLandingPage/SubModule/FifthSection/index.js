import React from 'react';
import "../../style.css";

function FifthSection() {
    return (
        <div className="fifth-section">
            5
        </div>
    )
}


export default FifthSection;