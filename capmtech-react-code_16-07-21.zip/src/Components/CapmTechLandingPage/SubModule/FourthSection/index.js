import React from 'react';
import "../../style.css";

function FourthSection() {
    return (
        <div className="fourth-section">
            4
        </div>
    )
}


export default FourthSection;